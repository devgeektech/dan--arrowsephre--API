array (
  'sans-serif' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'Helvetica',
    'bold' => DOMPDF_FONT_DIR . 'Helvetica-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Helvetica-Oblique',
    'bold_italic' => DOMPDF_FONT_DIR . 'Helvetica-BoldOblique',   
  ),
  'times' =>
  array (
    'normal' => DOMPDF_FONT_DIR . 'Times-Roman',
    'bold' => DOMPDF_FONT_DIR . 'Times-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Times-Italic',
    'bold_italic' => DOMPDF_FONT_DIR . 'Times-BoldItalic',
  ),
  'times-roman' =>
  array (
    'normal' => DOMPDF_FONT_DIR . 'Times-Roman',
    'bold' => DOMPDF_FONT_DIR . 'Times-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Times-Italic',
    'bold_italic' => DOMPDF_FONT_DIR . 'Times-BoldItalic',
  ),
  'courier' =>
  array (
    'normal' => DOMPDF_FONT_DIR . 'Courier',
    'bold' => DOMPDF_FONT_DIR . 'Courier-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Courier-Oblique',
    'bold_italic' => DOMPDF_FONT_DIR . 'Courier-BoldOblique',
  ),
  'helvetica' =>
  array (
    'normal' => DOMPDF_FONT_DIR . 'Helvetica',
    'bold' => DOMPDF_FONT_DIR . 'Helvetica-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Helvetica-Oblique',
    'bold_italic' => DOMPDF_FONT_DIR . 'Helvetica-BoldOblique',   
  ),
  'zapfdingbats' =>
  array (
    'normal' => DOMPDF_FONT_DIR . 'ZapfDingbats',
    'bold' => DOMPDF_FONT_DIR . 'ZapfDingbats',
    'italic' => DOMPDF_FONT_DIR . 'ZapfDingbats',
    'bold_italic' => DOMPDF_FONT_DIR . 'ZapfDingbats',   
  ),
  'serif' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'Times-Roman',
    'bold' => DOMPDF_FONT_DIR . 'Times-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Times-Italic',
    'bold_italic' => DOMPDF_FONT_DIR . 'Times-BoldItalic',
  ),
  'monospace' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'Courier',
    'bold' => DOMPDF_FONT_DIR . 'Courier-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Courier-Oblique',
    'bold_italic' => DOMPDF_FONT_DIR . 'Courier-BoldOblique',
  ),
  'fixed' => 
  array (
    'normal' => DOMPDF_FONT_DIR . 'Courier',
    'bold' => DOMPDF_FONT_DIR . 'Courier-Bold',
    'italic' => DOMPDF_FONT_DIR . 'Courier-Oblique',
    'bold_italic' => DOMPDF_FONT_DIR . 'Courier-BoldOblique',
  ),
//  'arial' => 
//  array (
//    'normal' => DOMPDF_FONT_DIR . 'Arial',
//    'bold' => DOMPDF_FONT_DIR . 'Arial_Bold',
//    'italic' => DOMPDF_FONT_DIR . 'Arial_Italic',
//    'bold_italic' => DOMPDF_FONT_DIR . 'Arial_Bold_Italic',
//  ),
//  'comic sans' =>
//  array (
//    'normal' => DOMPDF_FONT_DIR . 'Comic_Sans_MS.ttf',
//    'bold' => DOMPDF_FONT_DIR . 'Comic_Sans_MS_Bold.ttf',
//    'italic' => DOMPDF_FONT_DIR . 'Comic_Sans_MS.ttf',
//    'bold_italic' => DOMPDF_FONT_DIR . 'Comic_Sans_MS.ttf',
//  ),
//  'georgia' => 
//  array (
//    'normal' => DOMPDF_FONT_DIR . 'Georgia',
//    'bold' => DOMPDF_FONT_DIR . 'Georgia_Bold',
//    'italic' => DOMPDF_FONT_DIR . 'Georgia_Italic',
//    'bold_italic' => DOMPDF_FONT_DIR . 'Georgia_Bold_Italic',
//  ),
//  'lucida console' => 
//  array (
//    'normal' => DOMPDF_FONT_DIR . 'lucon',
//    'bold' => DOMPDF_FONT_DIR . 'lucon',
//    'italic' => DOMPDF_FONT_DIR . 'lucon',
//    'bold_italic' => DOMPDF_FONT_DIR . 'lucon',
//  ),
//  'times new roman' => 
//  array (
//    'normal' => DOMPDF_FONT_DIR . 'Times_New_Roman',
//    'bold' => DOMPDF_FONT_DIR . 'Times_New_Roman_Bold',
//    'italic' => DOMPDF_FONT_DIR . 'Times_New_Roman_Italic',
//    'bold_italic' => DOMPDF_FONT_DIR . 'Times_New_Roman_Bold_Italic',
//  ),
//  'trebuchet' => 
//  array (
//    'normal' => DOMPDF_FONT_DIR . 'Trebuchet_MS',
//    'bold' => DOMPDF_FONT_DIR . 'Trebuchet_MS_Bold',
//    'italic' => DOMPDF_FONT_DIR . 'Trebuchet_MS_Italic',
//    'bold_italic' => DOMPDF_FONT_DIR . 'Trebuchet_MS_Bold_Italic',
//  ),
//  'trebuchet ms' => 
//  array (
//    'normal' => DOMPDF_FONT_DIR . 'Trebuchet_MS',
//    'bold' => DOMPDF_FONT_DIR . 'Trebuchet_MS_Bold',
//    'italic' => DOMPDF_FONT_DIR . 'Trebuchet_MS_Italic',
//    'bold_italic' => DOMPDF_FONT_DIR . 'Trebuchet_MS_Bold_Italic',
//  ),
//  'silkscreen' => 
//  array (
//    'normal' => DOMPDF_FONT_DIR . 'slkscr',
//    'bold' => DOMPDF_FONT_DIR . 'slkscrb',
//    'italic' => DOMPDF_FONT_DIR . 'slkscr',
//    'bold_italic' => DOMPDF_FONT_DIR . 'slkscr',
//  ),
//  'silkscreen expanded' => 
//  array (
//    'normal' => DOMPDF_FONT_DIR . 'slkscre',
//    'bold' => DOMPDF_FONT_DIR . 'slkscreb',
//    'italic' => DOMPDF_FONT_DIR . 'slkscre',
//    'bold_italic' => DOMPDF_FONT_DIR . 'slkscre',
//  ),
//  'verdana' => 
//  array (
//    'normal' => DOMPDF_FONT_DIR . 'Verdana',
//    'bold' => DOMPDF_FONT_DIR . 'Verdana_Bold',
//    'italic' => DOMPDF_FONT_DIR . 'Verdana_Italic',
//    'bold_italic' => DOMPDF_FONT_DIR . 'Verdana_Bold_Italic',
//  ),
)