<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="<?php echo ASSETS_URL . '/css/ppcore.css' ?>">
	<style type="text/css"></style>
</head>
<body>
Loading...
</body>
</html>