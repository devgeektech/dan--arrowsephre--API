
<div id="instructions">
	<h2><?php _e('How to use','simplr-registration-form'); ?></h2>
	<p>
	<?php _e('Simply navigate to the edit screen for the post or page on which you would like the form to appear and click the Registration button on the TinyMCE (shown at the right).','simplr-registration-form'); ?>
	</p>

	<p><?php _e('For updates please visit:','simplr-registration-form'); ?> <a href="http://www.mikevanwinkle.com/simplr-registration-form-plus/" title="<?php _e('Simplr Registration Form','simplr-registration-form'); ?>" target="_blank">http://www.mikevanwinkle.com/simplr-registration-form-plus/</a></p>

	<div id="inst-video">
		<iframe src="http://player.vimeo.com/video/23532472?title=0&amp;byline=0&amp;portrait=0" width="600" height="450" frameborder="0"></iframe>
	</div>

</div>
