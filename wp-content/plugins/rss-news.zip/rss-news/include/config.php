<?php
// change the values to fit yours
$db_config = array(
	'host' => 'localhost',
	'user' => 'root',
	'pass' => '',
	'name' => 'test_db'
);