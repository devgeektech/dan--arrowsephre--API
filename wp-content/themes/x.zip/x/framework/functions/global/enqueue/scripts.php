<?php

// =============================================================================
// FUNCTIONS/GLOBAL/ENQUEUE/SCRIPTS.PHP
// -----------------------------------------------------------------------------
// Theme scripts.
// =============================================================================

// =============================================================================
// TABLE OF CONTENTS
// -----------------------------------------------------------------------------
//   01. Enqueue Site Scripts
//   02. Enqueue Admin Scripts
//   03. Enqueue Customizer Scripts
// =============================================================================

// Enqueue Site Scripts
// =============================================================================

if ( ! function_exists( 'x_enqueue_site_scripts' ) ) :
  function x_enqueue_site_scripts() {

    wp_register_script( 'x-site-head', X_TEMPLATE_URL . '/framework/js/dist/site/x-head.min.js', array( 'jquery' ), X_VERSION, false );
    wp_register_script( 'x-site-body', X_TEMPLATE_URL . '/framework/js/dist/site/x-body.min.js', array( 'jquery' ), X_VERSION, true );
    wp_register_script( 'x-site-icon', X_TEMPLATE_URL . '/framework/js/dist/site/x-icon.min.js', array( 'jquery' ), X_VERSION, true );

    wp_enqueue_script( 'x-site-head' );
    wp_enqueue_script( 'x-site-body' );

    if ( x_get_stack() == 'icon' ) {
      wp_enqueue_script( 'x-site-icon' );
    }

    if ( is_singular() ) {
      wp_enqueue_script( 'comment-reply' );
    }

    if ( X_BUDDYPRESS_IS_ACTIVE ) {
      wp_dequeue_script( 'bp-legacy-js' );
      wp_dequeue_script( 'bp-parent-js' );
      wp_enqueue_script( 'x-site-buddypress', X_TEMPLATE_URL . '/framework/js/dist/site/x-buddypress.js', bp_core_get_js_dependencies(), X_VERSION, false );
      wp_localize_script( 'x-site-buddypress', 'BP_DTheme', x_buddypress_core_get_js_strings() );
    }

  }
  add_action( 'wp_enqueue_scripts', 'x_enqueue_site_scripts' );
endif;



// Enqueue Admin Scripts
// =============================================================================

if ( ! function_exists( 'x_enqueue_post_meta_scripts' ) ) :
  function x_enqueue_post_meta_scripts( $hook ) {

    GLOBAL $post;
    GLOBAL $wp_customize;

    if ( isset( $wp_customize ) ) {
      return;
    }

    wp_enqueue_script( 'wp-color-picker');
    wp_enqueue_script( 'x-confirm-js', X_TEMPLATE_URL . '/framework/js/dist/admin/x-confirm.min.js', array( 'jquery' ), X_VERSION, true );

    if ( strpos( $hook, 'x-addons-customizer-manager' ) != false ) {
      wp_enqueue_script( 'x-customizer-admin-js', X_TEMPLATE_URL . '/framework/js/dist/admin/x-customizer-admin.min.js', array( 'jquery' ), X_VERSION, true );
    }

    if ( $hook == 'widgets.php' ) {
      wp_enqueue_script( 'x-widgets-js', X_TEMPLATE_URL . '/framework/js/dist/admin/x-widgets.min.js', array( 'jquery' ), X_VERSION, true );
    }

    if ( $hook == 'post.php' || $hook == 'post-new.php' || $hook == 'edit-tags.php' ) {
      wp_enqueue_script( 'x-meta-js', X_TEMPLATE_URL . '/framework/js/dist/admin/x-meta.min.js', array( 'jquery', 'media-upload', 'thickbox' ), X_VERSION, true );
    }

    if ( $hook == 'post.php' || $hook == 'post-new.php' || strpos( $hook, 'x-extensions' ) != false ) {
      wp_enqueue_script( 'jquery-ui-datepicker' );
    }

  }
  add_action( 'admin_enqueue_scripts', 'x_enqueue_post_meta_scripts' );
endif;



// Enqueue Customizer Scripts
// =============================================================================

//
// Controls.
//

if ( ! function_exists( 'x_enqueue_customizer_controls_scripts' ) ) :
  function x_enqueue_customizer_controls_scripts() {

    wp_enqueue_script( 'x-customizer-controls-js', X_TEMPLATE_URL . '/framework/js/dist/admin/x-customizer-controls.min.js', array( 'jquery' ), X_VERSION, true );

  }
  add_action( 'customize_controls_print_footer_scripts', 'x_enqueue_customizer_controls_scripts' );
endif;


//
// Preview.
//

if ( ! function_exists( 'x_enqueue_customizer_preview_scripts' ) ) :
  function x_enqueue_customizer_preview_scripts() {

    wp_enqueue_script( 'x-customizer-preview-js', X_TEMPLATE_URL . '/framework/js/dist/admin/x-customizer-preview.min.js', array( 'jquery', 'customize-preview', 'heartbeat' ), X_VERSION, true );

  }
  add_action( 'customize_preview_init', 'x_enqueue_customizer_preview_scripts' );
endif;